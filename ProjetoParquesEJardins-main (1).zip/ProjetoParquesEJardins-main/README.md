# ProjetoParquesEJardins

Projeto para identificação dos espaços utilizando QRCode na Praça em Angra dos Reis
